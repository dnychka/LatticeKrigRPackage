##BEGIN HEADER
#
# LatticeKrig is a package for analysis of spatial data written for
# the R software environment.
# Copyright (C) 2026 Colorado School of Mines
# 1500 Illinois St., Golden, CO 80401
# Contact: Douglas Nychka,  douglasnychka@gmail.com,
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# A copy of the GNU General Public License is included
# along with the R software environment if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# or refer to  http://www.r-project.org/Licenses/GPL-2
#
##END HEADER

"predictSE.LKrig" <- function(object, xnew = NULL, Znew = object$Z, 
	verbose = FALSE, ...) {
	if (is.null(object$Mc)) {
		stop("need to include the sparse cholesky decompostion in LKrig object \r\nin calling LKrig set return.cholesky = TRUE")
	}
	if (is.null(object$LKinfo$fixedFunction)) {
		stop("Standard errors not supported without a fixed component")
	}
	# set some local variables
	NG <- nrow(xnew)
	lambda <- object$lambda
	sigma2 <- object$sigma2.MLE
	tau2 <- lambda * sigma2
	weights <- object$weights
# NOTE throughout the "w" added to variables, e.g. wX, wk0, is the sqrt(weights)
# not the weights	
	LKinfo <- object$LKinfo
	if( is.null( xnew)){
		xnew<- object$x
	}
# figure out if extra covariates should be included
if (is.null(Znew) & (object$nZ > 0)) {
		Znew <- object$Z
	}
	distance.type <- LKinfo$distance.type
	if(is.null(object$wU) | is.null( object$wX) ){
		stop("LKrig object must have the matrices wU and wX 
		 (see return.wXandwU = TRUE in LKrig)")}
# fixed effects matrix at the new locations		 
	t0 <- t(do.call(object$LKinfo$fixedFunction, c(list(x = xnew, 
		Z = Znew, distance.type = distance.type), LKinfo$fixedFunctionArgs)))
	Omega <- object$Omega
	#
#	wS  <- diag.spam(sqrt(weights))
#	wk0 <- wS%*% LKrig.cov(object$x, xnew, LKinfo = LKinfo)
	wk0 <- LKrigCovWeightedObs( xnew, object$wX, LKinfo = LKinfo)
    # use the predict computations but with covariance vector
    # as "observations"
    # it may not be obvious why this formula makes sense!	
	# collapseFixedEffect=FALSE because
	# we want the "fixed effect" d.coef computation
	# to be done separately for each column of wk0
	hold <- LKrig.coef(
	          GCholesky = object$Mc,
	                 wX = object$wX, 
		               wU = object$wU,
		               wy = wk0,
		           lambda = lambda,
		          verbose = verbose,
  collapseFixedEffect = FALSE
	             )
	# version of 'c'coefficents for usual Kriging model
	# as for  mKrig in  the fields package 
	c.mKrig <- (wk0 - object$wU %*% hold$d.coef
	                        - object$wX %*% hold$c.coef)/lambda
	d.coef <- hold$d.coef
	# colSums used to find multiple quadratic forms  
	#e.g.  diag(t(x) %*%A%*%x) == colSums( x* (A%*%(x)))
	temp1 <- sigma2 * (colSums(t0 * (Omega %*% t0)) -
	                      2 * colSums(t0 * d.coef))
	# find marginal variances -- trival in the stationary case!
	temp0 <- sigma2 * (LKrig.cov(xnew, LKinfo = LKinfo, marginal = TRUE) - 
		colSums(wk0 * c.mKrig))
	temp <- temp0 + temp1
	return(sqrt(temp))
}
